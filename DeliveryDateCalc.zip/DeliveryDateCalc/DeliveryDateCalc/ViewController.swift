//
//  ViewController.swift
//  DeliveryDateCalc
//
//  Created by MacSSD on 16/12/14.
//  Copyright (c) 2014 MacSSD. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    //This all are the Global varialbes
    var datePicker=UIDatePicker()
    var LMPTxtField=UITextField()
    var deliveryDateLbl=UILabel()
    var gestationalLbl=UILabel()
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        // Create a Label
        
        let LMPDateLbl:UILabel=UILabel(frame: CGRectMake(10.0, 40.0, 90.0, 30))
        LMPDateLbl.text="LMP Date:"
        self.view.addSubview(LMPDateLbl)
        
        //Create a textfield
        
        LMPTxtField=UITextField(frame: CGRectMake(105.0, 40.0, 150.0, 30))
        LMPTxtField.borderStyle=UITextBorderStyle.RoundedRect
        LMPTxtField.delegate=self;
        self.view.addSubview(LMPTxtField)
        
        //Create a Button
        let calc:UIButton=UIButton(frame: CGRectMake(105.0, 100.0, 90.0, 30))
        calc.setTitle("Calculate", forState: UIControlState.Normal)
        calc.setTitleColor(UIColor.redColor(), forState: UIControlState.Normal)
        calc.addTarget(self, action: #selector(ViewController.calcBtnAction), forControlEvents: UIControlEvents.TouchUpInside)
        self.view.addSubview(calc)
        
        deliveryDateLbl=UILabel(frame: CGRectMake(100.0, 160.0, 250.0, 30))
        self.view.addSubview(deliveryDateLbl)

        
        //Create a datePicker
        datePicker=UIDatePicker(frame: CGRectMake(00.0, 400.0, 400.0, 400.0))
        datePicker.datePickerMode=UIDatePickerMode.Date
        datePicker.addTarget(self, action: #selector(ViewController.datePickerAction), forControlEvents: UIControlEvents.ValueChanged)
        
    }
    
    func datePickerAction() {
        let df:NSDateFormatter=NSDateFormatter()
        df.dateStyle=NSDateFormatterStyle.MediumStyle
        LMPTxtField.text=df.stringFromDate(datePicker.date)
    }
    
    
    func calcBtnAction() {
        let secondsPerDay:NSTimeInterval=24*60*60
        let LMPDate:NSDate=datePicker.date
        let currentDate = NSDate()
        let deliveryDate:NSDate=LMPDate.dateByAddingTimeInterval(281*secondsPerDay)
        let df:NSDateFormatter=NSDateFormatter()
        df.dateStyle=NSDateFormatterStyle.MediumStyle
        deliveryDateLbl.text=df.stringFromDate(deliveryDate)
        
    }
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool
    {
        self.view.addSubview(datePicker)
        return false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

